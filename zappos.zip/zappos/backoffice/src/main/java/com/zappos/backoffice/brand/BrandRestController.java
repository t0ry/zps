package com.zappos.backoffice.brand;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.zappos.backoffice.exception.DataInconsistencyException;
import com.zappos.backoffice.exception.DuplicateResourceException;
import com.zappos.backoffice.exception.ResourceNotFoundException;

@RestController
@CrossOrigin(origins = "*")
public class BrandRestController {

  @Autowired
  private BrandRepository brandRepository;

  @GetMapping(path = "zappos/brands",
      produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
  public List<Brand> findAll() {
    return brandRepository.findAll();
  }

  @PostMapping(path = "zappos/brands",
      produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
      consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
  public Brand save(final @Valid @RequestBody Brand brand) {
    if (brandRepository.existsByName(brand.getName())) {
      throw new DuplicateResourceException("Brand", "name", brand.getName());
    }

    return brandRepository.save(brand);
  }

  @DeleteMapping(path = "zappos/brands/{id}",
      produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
      consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
  public void delete(final @PathVariable(value = "id") Integer id) {
    final Brand brandToDelete = brandRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Brand", "id", id));

    brandRepository.delete(brandToDelete);
  }

  @GetMapping(path = "zappos/brands/{id}",
      produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
  public Brand findById(final @PathVariable(value = "id") Integer id) {
    return brandRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Brand", "id", id));
  }

  @PutMapping(path = "zappos/brands/{id}",
      produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
      consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
  public Brand update(final @PathVariable(value = "id") Integer id,
      @Valid @RequestBody Brand newBrand) {

    if (newBrand.getId() != id) {
      throw new DataInconsistencyException("Brand", "id", newBrand.getId(), id);
    }

    final Brand oldBrand = brandRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Brand", "id", id));

    final Optional<Brand> brandWithNewName = brandRepository.findByName(newBrand.getName());
    if (brandWithNewName.isPresent() && !brandWithNewName.get().getId().equals(oldBrand.getId())) {
      throw new DuplicateResourceException("brand", "name", newBrand.getName());
    }

    oldBrand.setName(newBrand.getName());

    return brandRepository.save(oldBrand);
  }
}
