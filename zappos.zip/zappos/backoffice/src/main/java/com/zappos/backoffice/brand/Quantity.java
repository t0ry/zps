package com.zappos.backoffice.brand;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "quantity")
public class Quantity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Integer id;

  @Column(name = "time_recieved")
  @Temporal(TemporalType.TIMESTAMP)
  @JsonFormat(shape = JsonFormat.Shape.NUMBER)
  @NotNull(message = "received time must be specified")
  private Date receivedTime;

  @Column(name = "quantity")
  @PositiveOrZero(message = "quantity must be positive or 0")
  private long quantity;

  public Quantity() {}

  public Quantity(final Integer id, final Date receivedTime, final long quantity) {
    this.id = id;
    this.receivedTime = receivedTime;
    this.quantity = quantity;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Date getReceivedTime() {
    return receivedTime;
  }

  public void setReceivedTime(final Date receivedTime) {
    this.receivedTime = receivedTime;
  }

  public long getQuantity() {
    return quantity;
  }

  public void setQuantity(final long quantity) {
    this.quantity = quantity;
  }

  @Override
  public String toString() {
    return String.format("%s [id = %s; receivedTime = %s; quantity = %s]",
        this.getClass().getName(), id, receivedTime, quantity);
  }
}
