package com.zappos.backoffice.brand;

import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.xml.bind.annotation.XmlRootElement;
import org.hibernate.annotations.Formula;
import io.swagger.annotations.ApiModelProperty;

@Entity
@XmlRootElement
@Table(name = "brand")
public class Brand {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Integer id;

  @Column(name = "name", unique = true)
  @NotBlank(message = "'name' cannot be blank")
  private String name;

  @ApiModelProperty(hidden = true)
  @Formula("(SELECT coalesce(sum(quantity.quantity), 0) FROM quantity WHERE quantity.brand_id = id)")
  private long totalQuantity;

  @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "brand_id", nullable = false)
  private List<Quantity> quantities;

  public Brand() {}

  public Brand(final int id, final String name, final List<Quantity> quantities) {
    this.id = id;
    this.name = name;
    this.setQuantities(quantities);
  }

  public Brand(final String name) {
    this.name = name;
  }

  public Integer getId() {
    return id;
  }

  public void setId(final Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(final String name) {
    this.name = name;
  }

  @Formula("(SELECT coalesce(sum(quantity.quantity), 0) FROM Quantity WHERE quantity.brand_id = id)")
  public long getTotalQuantity() {
    return totalQuantity;
  }

  public void setQuantities(List<Quantity> quantities) {
    this.quantities = quantities;
  }

  @Override
  public boolean equals(final Object other) {
    if (other == null) {
      return false;
    }
    if (this == other) {
      return true;
    }
    if (!this.getClass().equals(other.getClass())) {
      return false;
    }
    final Brand otherBrand = (Brand) other;
    return this.id.equals(otherBrand.getId()) && this.name.equals(otherBrand.getName());
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name);
  }

  @Override
  public String toString() {
    return String.format("%s [id = %s; name = %s; quantity = %s]", this.getClass().getName(), id,
        name, totalQuantity);
  }
}
