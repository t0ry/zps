package com.zappos.backoffice.inventory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins = "*")
@RepositoryRestResource(path = "inventory", collectionResourceRel = "inventory")
public interface InventoryRepository extends JpaRepository<Sum, Integer> {

  @RestResource(path = "sum", rel = "customFindMethod")
  @Query(value = "SELECT coalesce(sum(q.quantity), 0) FROM quantity q", nativeQuery = true)
  Long findInventorySum();
}
