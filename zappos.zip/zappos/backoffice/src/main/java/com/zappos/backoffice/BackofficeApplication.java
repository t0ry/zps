package com.zappos.backoffice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableAutoConfiguration
public class BackofficeApplication {

  public static void main(String[] args) {
    SpringApplication.run(BackofficeApplication.class, args);
  }

}
