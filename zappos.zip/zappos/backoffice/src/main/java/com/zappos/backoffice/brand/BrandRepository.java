package com.zappos.backoffice.brand;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins = "*")
public interface BrandRepository extends JpaRepository<Brand, Integer> {

  boolean existsByName(final String name);

  Optional<Brand> findByName(final String name);
}
