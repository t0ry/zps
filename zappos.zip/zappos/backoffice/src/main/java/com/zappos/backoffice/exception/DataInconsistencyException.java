package com.zappos.backoffice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.PRECONDITION_FAILED)
public class DataInconsistencyException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  private String resourceName;
  private String fieldName;
  private Object actualFieldValue;
  private Object expectedFieldValue;

  public DataInconsistencyException(final String resourceName, final String fieldName,
      final Object actualFieldValue, final Object expectedFieldValue) {
    super(String.format("%s has unexpected %s. Expected: '%s' but found: %s", resourceName,
        fieldName, expectedFieldValue, actualFieldValue));

    this.resourceName = resourceName;
    this.fieldName = fieldName;
    this.actualFieldValue = actualFieldValue;
    this.expectedFieldValue = expectedFieldValue;
  }

  public String getResourceName() {
    return resourceName;
  }

  public String getExpectedFieldName() {
    return fieldName;
  }

  public Object getExpectedFieldValue() {
    return expectedFieldValue;
  }

  public Object getActualFieldValue() {
    return actualFieldValue;
  }
}

