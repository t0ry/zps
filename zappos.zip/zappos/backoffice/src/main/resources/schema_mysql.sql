CREATE DATABASE  IF NOT EXISTS `backoffice`;
USE `backoffice`;

-- db structure
-- clean --
ALTER TABLE `quantity`
	DROP FOREIGN KEY `fk_brand_id`;
    
DROP TABLE IF EXISTS `quantity`;
DROP TABLE IF EXISTS `brand`;

-- set up --
-- brand --

CREATE TABLE `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL unique,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- quantity --
CREATE TABLE `quantity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time_recieved` timestamp NOT NULL,
  `quantity` long DEFAULT NULL,
  `brand_id` int NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY fk_brand_id(brand_id)
   REFERENCES brand(id)
   ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- Data --
-- brand --

INSERT INTO `brand` VALUES 
	(1,'COlumbia'),
	(2,'Levi\'s'),
	(3,'Zara'),
	(4,'Noname'),
	(5,'SOmth');
