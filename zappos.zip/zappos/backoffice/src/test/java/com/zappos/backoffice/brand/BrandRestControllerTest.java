package com.zappos.backoffice.brand;

import static org.junit.Assert.assertEquals;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;
import com.zappos.backoffice.exception.DataInconsistencyException;
import com.zappos.backoffice.exception.DuplicateResourceException;
import com.zappos.backoffice.exception.ResourceNotFoundException;

@RunWith(SpringRunner.class)
public class BrandRestControllerTest {

  @TestConfiguration
  static class BrandRestControllerTestContextConfiguration {

    @Bean
    public BrandRestController brandRestController() {
      return new BrandRestController();
    }
  }

  @Autowired
  private BrandRestController brandRestController;

  @MockBean
  private BrandRepository brandRepository;

  @Test
  public void findAllTest() {
    final List<Brand> expectedBrands =
        Arrays.asList(new Brand(1, "brand1", Collections.emptyList()),
            new Brand(2, "brand2", Collections.emptyList()));
    Mockito.when(brandRepository.findAll()).thenReturn(expectedBrands);

    List<Brand> actualBrands = brandRestController.findAll();

    assertEquals(actualBrands, expectedBrands);
  }

  @Test
  public void findByIdTest() {
    final Brand expectedBrand = new Brand(1, "brand1", Collections.emptyList());
    Mockito.when(brandRepository.findById(expectedBrand.getId()))
        .thenReturn(Optional.of(expectedBrand));

    final Integer expectedId = expectedBrand.getId();
    Brand actualBrand = brandRestController.findById(expectedId);

    assertEquals(actualBrand.getId(), expectedId);
  }

  @Test(expected = ResourceNotFoundException.class)
  public void findByIdWithNotFoundTest() {
    final int expectedId = 100000;
    Mockito.when(brandRepository.findById(expectedId)).thenReturn(Optional.empty());

    brandRestController.findById(expectedId);
  }

  @Test
  public void saveTest() {
    final Brand brandToSave = new Brand(100, "brand 100", Collections.emptyList());
    Mockito.when(brandRepository.save(brandToSave)).thenReturn(brandToSave);

    final Brand actualBrand = brandRestController.save(brandToSave);

    Mockito.verify(brandRepository).save(brandToSave);
    assertEquals(actualBrand, brandToSave);
  }

  @Test(expected = DuplicateResourceException.class)
  public void saveWithNameConflictTest() {
    final Brand brandToSave = new Brand(100, "brand 100", Collections.emptyList());
    Mockito.when(brandRepository.existsByName(brandToSave.getName())).thenReturn(true);

    brandRestController.save(brandToSave);

    Mockito.verify(brandRepository, Mockito.never()).save(Mockito.any());
  }

  @Test
  public void updateTest() {
    final Brand oldBrand = new Brand(100, "brand 100", Collections.emptyList());
    Mockito.when(brandRepository.findById(oldBrand.getId())).thenReturn(Optional.of(oldBrand));
    final Brand expectedBrand = new Brand(100, "brand 100 updated", Collections.emptyList());
    Mockito.when(brandRepository.save(expectedBrand)).thenReturn(expectedBrand);

    final Brand actualBrand = brandRestController.update(expectedBrand.getId(), expectedBrand);

    Mockito.verify(brandRepository).save(expectedBrand);
    assertEquals(actualBrand, expectedBrand);
  }

  @Test(expected = DataInconsistencyException.class)
  public void updateWithInconsistendDataTest() {
    final Brand brandToUpdate = new Brand(100, "brand 100", Collections.emptyList());

    brandRestController.update(1, brandToUpdate);

    Mockito.verifyZeroInteractions(brandRepository);
  }

  @Test(expected = DuplicateResourceException.class)
  public void updateWithNameConflictTest() {
    final Brand updatedBrand = new Brand(100, "brand 100 updated", Collections.emptyList());
    final Brand anotherBrandWithSameName =
        new Brand(200, "brand 100 updated", Collections.emptyList());

    Mockito.when(brandRepository.findById(updatedBrand.getId()))
        .thenReturn(Optional.of(updatedBrand));
    Mockito.when(brandRepository.findByName(updatedBrand.getName()))
        .thenReturn(Optional.of(anotherBrandWithSameName));

    brandRestController.update(updatedBrand.getId(), updatedBrand);

    Mockito.verify(brandRepository, Mockito.never()).save(Mockito.any());
  }

  @Test(expected = ResourceNotFoundException.class)
  public void updateWithAbsentIdTest() {
    final Brand updatedBrand = new Brand(100, "brand 100 updated", Collections.emptyList());

    Mockito.when(brandRepository.findById(updatedBrand.getId())).thenReturn(Optional.empty());

    brandRestController.update(updatedBrand.getId(), updatedBrand);

    Mockito.verify(brandRepository, Mockito.never()).save(Mockito.any());
  }

  @Test(expected = ResourceNotFoundException.class)
  public void deleteWithAbsentIdTest() {
    Mockito.when(brandRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());

    brandRestController.delete(1);

    Mockito.verify(brandRepository, Mockito.never()).delete(Mockito.any());
  }

  @Test
  public void deleteTest() {
    final Brand brandToDelete = new Brand(100, "brand to delete", Collections.emptyList());
    Mockito.when(brandRepository.findById(brandToDelete.getId()))
        .thenReturn(Optional.of(brandToDelete));

    brandRestController.delete(brandToDelete.getId());

    Mockito.verify(brandRepository).delete(brandToDelete);
  }
}
