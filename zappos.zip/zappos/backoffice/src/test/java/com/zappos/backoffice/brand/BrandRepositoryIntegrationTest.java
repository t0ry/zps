package com.zappos.backoffice.brand;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class BrandRepositoryIntegrationTest {

  @Autowired
  private TestEntityManager entityManager;
  @Autowired
  private BrandRepository brandRepository;

  private static final List<Brand> BRANDS = Arrays.asList(new Brand("brand1"), new Brand("brand2"));

  @Before
  public void beforeTest() {
    entityManager.clear();
    BRANDS.forEach(b -> {
      b.setId(null);

      entityManager.persist(b);
      entityManager.flush();
    });
  }

  @Test
  public void findByIdTest() {
    final Brand expectedBrand = BRANDS.get(0);
    final Optional<Brand> actualBrand = brandRepository.findById(expectedBrand.getId());

    assertTrue(actualBrand.isPresent());
    assertEquals(actualBrand.get().getId(), expectedBrand.getId());
    assertEquals(actualBrand.get().getName(), expectedBrand.getName());
    assertEquals(actualBrand.get().getTotalQuantity(), 0);
  }

  @Test
  public void existsByNameTest() {
    final Brand brandToCheck = BRANDS.get(0);

    final boolean actualExists = brandRepository.existsByName(brandToCheck.getName());
    final boolean actualNotExist = brandRepository.existsByName("noname");

    assertTrue(actualExists);
    assertFalse(actualNotExist);
  }

  @Test
  public void existsByIdTest() {
    final Brand brandToCheck = BRANDS.get(0);

    final boolean actualExists = brandRepository.existsById(brandToCheck.getId());
    final boolean actualNotExist = brandRepository.existsById(1234567);

    assertTrue(actualExists);
    assertFalse(actualNotExist);
  }


  @Test
  public void findAllTest() {
    final List<Brand> actualBrands = brandRepository.findAll();

    assertEquals(BRANDS.size(), actualBrands.size());
    actualBrands.forEach(b -> {
      assertTrue(BRANDS.contains(b));
    });
  }

  @Test
  public void saveTest() {

    final Brand brandToSave = new Brand(1000, "name1000", Collections.emptyList());

    final Brand actualBrand = brandRepository.save(brandToSave);

    assertNotNull(actualBrand);
    assertEquals(actualBrand.getName(), brandToSave.getName());
    assertEquals(actualBrand.getTotalQuantity(), 0);
  }

  // @Test
  // public void saveWithQuantitiesTest() {
  //
  // final Brand brandToSave =
  // new Brand(1000, "name1000", Arrays.asList(new Quantity(null, new Date(), 12)));
  //
  // final Brand actualBrand = brandRepository.save(brandToSave);
  // final Brand brandFromDb = brandRepository.findById(actualBrand.getId()).get();
  //
  // assertNotNull(actualBrand);
  // assertEquals(actualBrand.getName(), brandToSave.getName());
  // assertEquals(actualBrand.getQuantity(), 0);
  // }

  @Test
  public void updateTest() {
    final Brand brandToUpdate = BRANDS.get(0);
    brandToUpdate.setName("new name");

    final Brand actualBrand = brandRepository.save(brandToUpdate);

    assertNotNull(actualBrand);
    assertEquals(actualBrand, brandToUpdate);
  }

  @Test
  public void deleteTest() {
    final Brand brandToDelete = BRANDS.get(0);
    assertNotNull(entityManager.find(Brand.class, brandToDelete.getId()));

    brandRepository.delete(brandToDelete);

    assertNull(entityManager.find(Brand.class, brandToDelete.getId()));
  }
}
