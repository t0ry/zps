package com.zappos.backoffice.inventory;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataJpaTest
public class InventoryRepositoryTest {

  @Autowired
  private InventoryRepository inventoryRepository;

  @Test
  @Sql("inventory.sql")
  public void findInventorySumTest() {
    final Long actualSum = inventoryRepository.findInventorySum();
    
    assertEquals(actualSum.longValue(), 216L);
  }
  
  @Test
  public void findInventorySumWithNoDataTest() {
    final Long actualSum = inventoryRepository.findInventorySum();
    
    assertEquals(actualSum.longValue(), 0L);
  }
}
