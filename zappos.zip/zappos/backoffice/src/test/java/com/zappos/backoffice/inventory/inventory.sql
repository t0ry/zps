INSERT INTO brand (id, name) VALUES (1, 'Nike');
INSERT INTO brand (id, name) VALUES (2, 'Asics');
INSERT INTO brand (id, name) VALUES (3, 'Lucky');

INSERT INTO quantity (quantity, time_recieved, brand_id) VALUES (12, '2018-10-01 10:12:00.0', 1);
INSERT INTO quantity (quantity, time_recieved, brand_id) VALUES (45, '2018-10-01 10:15:00.0', 2);
INSERT INTO quantity (quantity, time_recieved, brand_id) VALUES (67, '2018-10-02 10:17:00.0', 3);
INSERT INTO quantity (quantity, time_recieved, brand_id) VALUES (35, '2018-10-02 10:14:00.0', 1);
INSERT INTO quantity (quantity, time_recieved, brand_id) VALUES (57, '2018-10-03 10:12:00.0', 2);