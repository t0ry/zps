import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

import Create from "./components/create.component";
import Welcome from "./components/welcome.component";

import logo from "./logo.png";
class App extends Component {
  render() {
    return (
        <Router>
            <div className="container">

                <nav className="navbar navbar-expand-lg navbar-light bg-light">
                    <div className="navbar navbar-expand-lg">
                        <img src={logo} width="50" height="50" alt="Cool Brands leave here" />
                    </div>
                    <Link to="/" className="navbar-brand"> Front Office Demo App</Link>
                    <div className="collpase nav-collapse">
                        <ul className="navbar-nav mr-auto">
                            <li className="navbar-item">
                                <Link to="/" className="nav-link">Brands</Link>
                            </li>
                            <li className="navbar-item">
                                <Link to="/create" className="nav-link">Add Cool Brand</Link>
                            </li>
                        </ul>
                    </div>
                </nav>


                <Route path="/" exact component={Welcome} />
                <Route path="/create" component={Create} />
            </div>
        </Router>
    		);
  }
}

export default App;
