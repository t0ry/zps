import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import {withStyles} from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import Divider from '@material-ui/core/Divider';
import {config} from "./../config.js";

const API = config.apiUrl;
const styles = theme => ({
    container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
    },
    dense: {
        marginTop: 16,
    },
    menu: {
        width: 200,
    },
    margin: {
        margin: theme.spacing.unit,
    },
    extendedIcon: {
        marginRight: theme.spacing.unit,
    },
});

class OutlinedTextFields extends React.Component {

    constructor(props) {
        super(props);
        this.handleSubmit = this.handleSubmit.bind(this);
    }


    state = {
        response: {status: 200, json: {}},
        isSuccess: true,
        fields: {name: "", quantity: "0"},
        errors: {},
        isValid: {name: false, quantity: true},
        isLoading: false,
        submitSuccessMessage: "",
        submitErrorMessage: "",
    };

    handleSubmit(event) {
        event.preventDefault();

        let brandToSumbit = {
            'name': this.state.fields['name'],
            'quantities': [
                {
                    'quantity': parseFloat(this.state.fields['quantity']),
                    'receivedTime': Date.now()
                }]
        };

        this.setState({isLoading: true, isSuccess: true, submitErrorMessage: "", submitSuccessMessage: ""});

        fetch(API, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(brandToSumbit)
        })
            .then((response) => {
                if (response.ok) {
                    return response.json();
                }
                throw new Error(JSON.stringify(response.json()));
            })
            .then((json) => {
                console.log("!!!!" + JSON.stringify(json));
                {
                    this.setState({
                        isLoading: false,
                        isSuccess: true,
                        submitErrorMessage: "",
                        submitSuccessMessage: "Brand has been sent.",
                        fields: {
                            name: '', quantity: '0'
                        }
                    })
                }
            })
            .catch((error) => {
                console.log("!!! Error: " + error)
                {
                    this.setState({
                        isLoading: false,
                        isSuccess: false,
                        submitErrorMessage: "Unable to save brand.",
                        submitSuccessMessage: ""
                    })
                }
            });
    }

    handleNameChange = field => event => {
        let fields = this.state.fields;
        fields['name'] = event.target.value;

        let errors = this.state.errors;
        let isFormValid = this.state.isValid;

        if (fields['name'].length === 0) {
            errors['name'] = "Brand name must be set!";
            isFormValid['name'] = false;
        } else {
            errors['name'] = "";
            isFormValid['name'] = true;
        }

        this.setState({fields, errors, isValid: isFormValid});
        console.log(JSON.stringify(this.state.isValid));
    }

    handleQuantityChange = field => event => {
        let fields = this.state.fields;
        fields['quantity'] = event.target.value;

        let errors = this.state.errors;
        let isFormValid = this.state.isValid;

        if (!event.target.value.match(/^[0-9]+$/)) {
            errors['quantity'] = "Must be set to positive number or 0";
            isFormValid['quantity'] = false;
        } else {
            errors['quantity'] = "";
            isFormValid['quantity'] = true;
        }

        this.setState({fields, errors, isValid: isFormValid});
    }


    render() {
        const {classes} = this.props;
        const {error, isSuccess, isLoading} = this.state;

        if (isLoading) {
            return (
                <div>
                    <Paper className={classes.root}>
                        <Typography variant="h6" component="h3">
                            Add Brand
                        </Typography>
                        <Typography component="p">
                            Loading ...
                        </Typography>
                    </Paper>
                </div>
            );
        }

        return (
            <div>
                <Typography variant="h6" component="h3" style={{paddingTop: 10}}>
                    Add Brand
                </Typography>
                <form className={classes.container} noValidate autoComplete="on" onSubmit={this.handleSubmit}>
                    <div style={{display: "inline-block", flow: "left"}}>
                        <TextField
                            required
                            id="tfName"
                            label="Name"
                            onChange={this.handleNameChange('name')}
                            className={classes.textField}
                            helperText={this.state.errors['name']}
                            error={this.state.errors['name'] == undefined || this.state.errors['name'].length == 0 ? false : true}
                            margin="normal"
                            variant="outlined"
                            style={{width: 400}}
                            value={this.state.fields['name']}

                        />

                        <TextField
                            id="tfQuantity"
                            label="Quantity"
                            onChange={this.handleQuantityChange('quantity')}
                            type="number"
                            defaultValue="0"
                            className={classes.textField}
                            margin="normal"
                            variant="outlined"
                            helperText={this.state.errors['quantity']}
                            error={this.state.errors['quantity'] == undefined || this.state.errors['quantity'].length == 0 ? false : true}
                            style={{width: 100}}
                        />

                        <div style={{paddingBottom: "20px"}}></div>
                        <Divider/>

                        <Button type="submit" variant="contained" size="small" color="default" style={{margin: "10px"}}
                                disabled={!this.state.isValid['name'] || !this.state.isValid['quantity']}>
                            Save
                        </Button>

                        <Typography component="p" color={"error"} style={{margin: 10, fontsize: "sizeSmall"}}>
                            {this.state.submitErrorMessage}
                        </Typography>
                        <Typography component="p" color={"primary"} style={{margin: 10, fontsize: "sizeSmall"}}>
                            {this.state.submitSuccessMessage}
                        </Typography>

                    </div>
                </form>
            </div>
        );
    }
}

OutlinedTextFields.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(OutlinedTextFields);
