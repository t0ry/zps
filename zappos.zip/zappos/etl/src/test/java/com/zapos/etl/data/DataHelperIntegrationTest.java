package com.zapos.etl.data;

import static org.junit.Assert.assertTrue;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class DataHelperIntegrationTest {

  @Rule
  public ExpectedException exceptionRule = ExpectedException.none();

  @Test
  public void fillDataFileTest() throws FileNotFoundException, IOException {
    final Path actualDataPath =
        Paths.get(DataHelper.class.getClassLoader().getResource("").getFile(), "data.sql");

    if (Files.exists(actualDataPath, LinkOption.NOFOLLOW_LINKS)) {
      Files.delete(actualDataPath);
    }

    DataHelper.fillDataFile("brands.tsv", "quantities.tsv");

    assertTrue(actualDataPath.toFile().exists());
  }

  @Test
  public void fillDataFileNullBrandsFileTest() throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("brandFileName is null");

    DataHelper.fillDataFile(null, "quantities.tsv");
  }

  @Test
  public void fillDataFileNullQuantitiesFileTest() throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("quantityFileName is null");

    DataHelper.fillDataFile("brands.tsv", null);
  }

  @Test
  public void fillDataFileIncorrectBrandsFileTest() throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("Unable to process wrong");

    DataHelper.fillDataFile("wrong", "quantities.tsv");
  }

  @Test
  public void fillDataFileIncorrectQuantitiesFileTest() throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("Unable to process wrong");

    DataHelper.fillDataFile("brands.tsv", "wrong");
  }
}
