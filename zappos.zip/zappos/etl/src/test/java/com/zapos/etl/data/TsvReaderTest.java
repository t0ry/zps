package com.zapos.etl.data;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertTrue;
import java.io.File;
import java.io.IOException;
import org.assertj.core.util.Arrays;
import org.junit.Test;

public class TsvReaderTest {

  @Test
  public void hasNextTokensTest() throws IOException {
    final File file = TestUtils.retrieveFileFromResource(this.getClass(), "reader/validTsv.tsv");
    assertTrue(file.exists());

    try (final TsvReader tsvReader = new TsvReader(file)) {
      assertTrue(tsvReader.hasNextTokens());
      tsvReader.nextTokens();
      assertTrue(tsvReader.hasNextTokens());
      tsvReader.nextTokens();
      assertTrue(!tsvReader.hasNextTokens());
    }
  }

  @Test
  public void hasNextTokensWithEmptyFileTest() throws IOException {
    final File file = TestUtils.retrieveFileFromResource(this.getClass(), "emptyFile.tsv");
    assertTrue(file.exists());

    try (final TsvReader tsvReader = new TsvReader(file)) {
      assertTrue(!tsvReader.hasNextTokens());
    }
  }

  @Test
  public void nextTokensTest() throws IOException {
    final File file = TestUtils.retrieveFileFromResource(this.getClass(), "reader/validTsv.tsv");
    assertTrue(file.exists());

    try (final TsvReader tsvReader = new TsvReader(file)) {
      assertArrayEquals(tsvReader.nextTokens(), Arrays.array("one", "two", "three"));
      assertArrayEquals(tsvReader.nextTokens(), Arrays.array("1", "2", "3"));
    }
  }
}
