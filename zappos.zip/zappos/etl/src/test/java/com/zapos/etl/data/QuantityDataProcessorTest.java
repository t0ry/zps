package com.zapos.etl.data;

import static org.junit.Assert.assertEquals;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class QuantityDataProcessorTest {

  @Rule
  public ExpectedException exceptionRule = ExpectedException.none();

  @Test
  public void prepareInsertStatementsTest() throws FileNotFoundException, IOException {
    List<String> expectedStatements = new ArrayList<>();
    expectedStatements.add(
        "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT 12, \"2018-10-01 10:12:00.0\", 1 WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = 1) > 0;");
    expectedStatements.add(
        "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT 45, \"2018-10-01 10:15:00.0\", 2 WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = 2) > 0;");
    expectedStatements.add(
        "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT 67, \"2018-10-02 10:17:00.0\", 3 WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = 3) > 0;");

    List<String> actualStatements = QuantityDataProcessor.INSTANCE.prepareInsertStatements(TestUtils
        .retrieveFileFromResource(QuantityDataProcessorTest.class, "quantity/quantitiesValid.tsv"));

    assertEquals(expectedStatements, actualStatements);
  }

  @Test
  public void prepareInsertStatementsColumnsPermutatedTest()
      throws FileNotFoundException, IOException {
    List<String> expectedStatements = new ArrayList<>();
    expectedStatements.add(
        "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT 12, \"2018-10-01 10:12:00.0\", 1 WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = 1) > 0;");
    expectedStatements.add(
        "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT 45, \"2018-10-01 10:15:00.0\", 2 WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = 2) > 0;");
    expectedStatements.add(
        "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT 67, \"2018-10-02 10:17:00.0\", 3 WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = 3) > 0;");

    List<String> actualStatements =
        QuantityDataProcessor.INSTANCE.prepareInsertStatements(TestUtils.retrieveFileFromResource(
            QuantityDataProcessorTest.class, "quantity/quantitiesValidColumnsPermutated.tsv"));

    assertEquals(expectedStatements, actualStatements);
  }

  @Test
  public void prepareInsertStatementsUnexectedCollumnTest()
      throws FileNotFoundException, IOException {
    List<String> expectedStatements = new ArrayList<>();
    expectedStatements.add(
        "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT 12, \"2018-10-01 10:12:00.0\", 1 WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = 1) > 0;");
    expectedStatements.add(
        "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT 45, \"2018-10-01 10:15:00.0\", 2 WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = 2) > 0;");
    expectedStatements.add(
        "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT 67, \"2018-10-02 10:17:00.0\", 3 WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = 3) > 0;");

    List<String> actualStatements =
        QuantityDataProcessor.INSTANCE.prepareInsertStatements(TestUtils.retrieveFileFromResource(
            QuantityDataProcessorTest.class, "quantity/quantitiesValidUnexpectedColumn.tsv"));

    assertEquals(expectedStatements, actualStatements);
  }

  @Test
  public void prepareInsertStatementsWithEmptyFileTest() throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("does not contain expeted data");

    List<String> actualStatements = QuantityDataProcessor.INSTANCE.prepareInsertStatements(
        TestUtils.retrieveFileFromResource(QuantityDataProcessorTest.class, "emptyFile.tsv"));
    assertEquals(Collections.emptyList(), actualStatements);
  }

  @Test
  public void prepareInsertStatementsOneInvalidColumnTest()
      throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("does not contain expeted data");

    QuantityDataProcessor.INSTANCE.prepareInsertStatements(TestUtils.retrieveFileFromResource(
        QuantityDataProcessorTest.class, "quantity/quantitiesOneColumnInvalid.tsv"));
  }

  @Test
  public void prepareInsertStatementsAllInvalidColumnsTest()
      throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("does not contain expeted data");

    QuantityDataProcessor.INSTANCE.prepareInsertStatements(TestUtils.retrieveFileFromResource(
        QuantityDataProcessorTest.class, "quantity/quantitiesAllColumnsInvalid.tsv"));
  }

  @Test
  public void prepareInsertStatementsNotTsvFileTest() throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("does not contain expeted data");

    QuantityDataProcessor.INSTANCE.prepareInsertStatements(
        TestUtils.retrieveFileFromResource(QuantityDataProcessorTest.class, "notTsv.tsv"));
  }


}
