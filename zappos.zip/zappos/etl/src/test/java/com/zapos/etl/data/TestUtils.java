package com.zapos.etl.data;

import java.io.File;

public class TestUtils {

  public static File retrieveFileFromResource(final Class<?> clazz, final String fileName) {
    return new File(clazz.getClassLoader().getResource(fileName).getFile());
  }
}
