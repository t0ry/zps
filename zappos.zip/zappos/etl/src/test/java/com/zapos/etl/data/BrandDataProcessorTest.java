package com.zapos.etl.data;

import static org.junit.Assert.assertEquals;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class BrandDataProcessorTest {

  @Rule
  public ExpectedException exceptionRule = ExpectedException.none();

  @Test
  public void prepareInsertStatementsTest() throws FileNotFoundException, IOException {
    List<String> expectedStatements = new ArrayList<>();
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (1, \"Nike\");");
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (2, \"Asics\");");
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (3, \"Lucky\");");
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (4, \"Timberland\");");
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (5, \"Levi's\");");
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (6, \"Rockport\");");

    List<String> actualStatements = BrandDataProcessor.INSTANCE.prepareInsertStatements(
        TestUtils.retrieveFileFromResource(BrandDataProcessorTest.class, "brand/brandsValid.tsv"));

    assertEquals(expectedStatements, actualStatements);
  }

  @Test
  public void prepareInsertStatementsColumnsPermutatedTest()
      throws FileNotFoundException, IOException {
    List<String> expectedStatements = new ArrayList<>();
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (1, \"Nike\");");
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (2, \"Asics\");");
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (3, \"Lucky\");");

    List<String> actualStatements =
        BrandDataProcessor.INSTANCE.prepareInsertStatements(TestUtils.retrieveFileFromResource(
            BrandDataProcessorTest.class, "brand/brandsValidColumnsPermutated.tsv"));

    assertEquals(expectedStatements, actualStatements);
  }

  @Test
  public void prepareInsertStatementsUnexectedCollumnTest()
      throws FileNotFoundException, IOException {
    List<String> expectedStatements = new ArrayList<>();
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (1, \"Nike\");");
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (2, \"Asics\");");
    expectedStatements.add("INSERT INTO `brand` (`id`, `name`) VALUES (3, \"Lucky\");");

    List<String> actualStatements =
        BrandDataProcessor.INSTANCE.prepareInsertStatements(TestUtils.retrieveFileFromResource(
            BrandDataProcessorTest.class, "brand/brandsValidUnexpectedColumn.tsv"));

    assertEquals(expectedStatements, actualStatements);
  }

  @Test
  public void prepareInsertStatementsWithEmptyFileTest() throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("does not contain expeted data");

    List<String> actualStatements = BrandDataProcessor.INSTANCE.prepareInsertStatements(
        TestUtils.retrieveFileFromResource(BrandDataProcessorTest.class, "emptyFile.tsv"));
    assertEquals(Collections.emptyList(), actualStatements);
  }

  @Test
  public void prepareInsertStatementsOneInvalidColumnTest()
      throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("does not contain expeted data");

    BrandDataProcessor.INSTANCE.prepareInsertStatements(TestUtils.retrieveFileFromResource(
        BrandDataProcessorTest.class, "brand/brandsOneColumnInvalid.tsv"));
  }

  @Test
  public void prepareInsertStatementsAllInvalidColumnsTest()
      throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("does not contain expeted data");

    BrandDataProcessor.INSTANCE.prepareInsertStatements(TestUtils.retrieveFileFromResource(
        BrandDataProcessorTest.class, "brand/brandsAllColumnsInvalid.tsv"));
  }

  @Test
  public void prepareInsertStatementsNotTsvFileTest() throws FileNotFoundException, IOException {
    exceptionRule.expect(IllegalArgumentException.class);
    exceptionRule.expectMessage("does not contain expeted data");

    BrandDataProcessor.INSTANCE.prepareInsertStatements(
        TestUtils.retrieveFileFromResource(BrandDataProcessorTest.class, "notTsv.tsv"));
  }
}
