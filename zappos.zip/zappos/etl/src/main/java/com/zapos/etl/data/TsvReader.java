package com.zapos.etl.data;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 * <h1>TsvReader
 * <h1/>Tsv scanner producing data in row-by-row manner.
 * 
 * Class supports a basic table format without escaping.
 */
class TsvReader implements Closeable {

  private final Scanner fileScanner;
  private String peekLine = null;

  /**
   * Constructs a new {@code TsvReader} for scanning {@code file}.
   */
  TsvReader(final File file) throws FileNotFoundException {
    fileScanner = new Scanner(file);
  }

  /**
   * Identifies if next token is available.
   * 
   * @return {@code true} if there is at least one unvisited token, otherwise returns {code false}
   */
  boolean hasNextTokens() {
    if (peekLine != null)
      return true;
    if (!fileScanner.hasNextLine()) {
      return false;
    }
    String line = fileScanner.nextLine().trim();
    if (line.isEmpty()) {
      return hasNextTokens();
    }
    this.peekLine = line;
    return true;
  }

  /**
   * Returns next unvisited token as array of {@code String}.
   * 
   * @return next unvisited token
   */
  String[] nextTokens() {
    if (!hasNextTokens())
      return null;
    String[] tokens = peekLine.split("[\\s\t]+");
    peekLine = null;
    return tokens;
  }

  @Override
  public void close() throws IOException {
    fileScanner.close();
  }
}
