package com.zapos.etl.data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <h1>DataProcessor</h1> Abstract processor for data provided from {@link TsvReader}. Provides
 * functionality for scanning columns and forming sql statements to fill db tables.
 */
abstract class DataProcessor {
  private static final Logger LOGGER = LoggerFactory.getLogger(DataProcessor.class);

  /**
   * Prepares {@code INSERT} statements for provided {@code dataFile}.
   * 
   * @param dataFile tsv file with first row as column names
   * @return collection of {@code INSERT} statements
   * @throws IOException if error occurs on scanning {@code dataFile}
   * @throws FileNotFoundException if {@code dataFile} does not exists
   */
  List<String> prepareInsertStatements(final File dataFile)
      throws IOException, FileNotFoundException {
    try (final TsvReader tsvReader = new TsvReader(dataFile)) {
      if (!tsvReader.hasNextTokens()) {
        throw new IllegalArgumentException(dataFile.getName() + " does not contain expeted data");
      }

      final Set<Column> columns = initColumns();
      fillColumnIndex(tsvReader, columns);

      if (!Validator.validateColumns(columns)) {
        throw new IllegalArgumentException(dataFile.getName() + " does not contain expeted data");
      }

      final List<String> insertStatements = extractData(tsvReader, columns);

      return insertStatements;
    }
  }

  /**
   * Initializes {@link Column}s setting up names.
   * 
   * @return
   */
  protected abstract Set<Column> initColumns();

  /**
   * Validates values in {@code dataRow} for {@code columns}.
   * 
   * @param dataRow data values representation
   * @param columns structure of {code dataRow}
   * @return
   */
  protected abstract boolean validateDataRow(final String[] dataRow, final Set<Column> columns);

  /**
   * Forms {@code INSERT} statement for {@code columns} with {@code dataRow}.
   * 
   * @param dataRow data values representation
   * @param columns structure of {code dataRow}
   * @return
   */
  protected abstract String formInsertStatement(final String[] dataRow, final Set<Column> columns);

  private List<String> extractData(final TsvReader tsvReader, final Set<Column> columns) {
    final List<String> insertStatements = new ArrayList<>();

    while (tsvReader.hasNextTokens()) {
      final String[] dataRow = tsvReader.nextTokens();

      if (!validateDataRow(dataRow, columns)) {
        LOGGER.error("Incorrect data format. Skipping item");
        continue;
      }

      try {
        insertStatements.add(formInsertStatement(dataRow, columns));
      } catch (NumberFormatException ex) {
        LOGGER.error("Incorrect data format. Skipping item. Reason: " + ex.getMessage());
      }
    }

    return insertStatements;
  }

  protected int findIndexByName(final Set<Column> columns, final String name) {
    int index = -1;
    for (final Column column : columns) {
      if (column.name.equalsIgnoreCase(name)) {
        index = column.getIndex();
      }
    }

    return index;
  }

  private static Set<Column> fillColumnIndex(final TsvReader tsvReader, final Set<Column> columns) {
    final String[] columnNames = tsvReader.nextTokens();

    for (int i = 0; i < columnNames.length; i++) {
      for (final Column column : columns) {
        if (column.getName().equalsIgnoreCase(columnNames[i])) {
          column.index = i;
        }
      }
    }

    return columns;
  }

  class Column {
    private String name;
    private int index = -1;

    Column(final String name) {
      this.name = name;
    }

    Column(final String name, final int index) {
      this.name = name;
      this.index = index;
    }

    private boolean isValid() {
      return index > -1;
    }

    String getName() {
      return name;
    }

    int getIndex() {
      return index;
    }
  }

  static class Validator {
    private static final Pattern DIGITS_ONLY_PATTERN = Pattern.compile("^[0-9]*$");

    static boolean validateNumber(final String... valueToValidate) {
      for (String value : valueToValidate) {
        if (!DIGITS_ONLY_PATTERN.matcher(value).matches()) {
          return false;
        }
      }
      return true;
    }

    private static boolean validateColumns(final Set<Column> columns) {
      for (Column column : columns) {
        if (!column.isValid()) {
          return false;
        }
      }
      return true;
    }
  }
}
