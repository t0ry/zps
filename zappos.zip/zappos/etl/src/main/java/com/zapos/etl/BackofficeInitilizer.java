package com.zapos.etl;

import java.io.IOException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.zapos.etl.data.DataHelper;

/**
 * <h1>BackofficeInitilizer</h1>
 * Spring Boot initializer for Backoffice web service. Extracts data from files provided as
 * command-line arguments, transforms to sql script and initializes database with provided data.
 */
@SpringBootApplication
public class BackofficeInitilizer {

  /*
   * Application entry point.
   */
  public static void main(String[] args) {
    System.setProperty("spring.datasource.url", System.getProperty("spring.datasource.url")
        + "?createDatabaseIfNotExist=true&connect=true&useLegacyDatetimeCode=false&serverTimezone=UTC");

    prepareSqlData();

    SpringApplication.run(BackofficeInitilizer.class, args);
  }

  private static void prepareSqlData() {
    try {
      DataHelper.fillDataFile(System.getProperty("brands"), System.getProperty("quantities"));
    } catch (IOException ex) {
      System.out.println("Unable to process data files: " + ex);
    } catch (IllegalArgumentException ex) {
      System.out.println("Incorrect arguments supplied: " + ex);
    }
  }

}
