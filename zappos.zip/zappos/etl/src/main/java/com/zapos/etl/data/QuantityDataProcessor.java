package com.zapos.etl.data;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;

/**
 * <h1>QuantityDataProcessor</h1> {@link DataProcessor} for {@code quantity}.
 */
class QuantityDataProcessor extends DataProcessor {
  private static final String QUANTITY_INSERT_PATTERN =
      "INSERT INTO `quantity` (`quantity`, `time_recieved`, `brand_id`) SELECT %s, \"%s\", %s "
          + "WHERE (SELECT count(`id`) FROM `brand` WHERE `id` = %s) > 0;";

  private static final String QUANTITY_BRAND_ID_COLUMN_NAME = "\"brand_id\"";
  private static final String QUANTITY_QUANTITY_COLUMN_NAME = "\"quantity\"";
  private static final String QUANTITY_TIME_RECIEVED_COLUMN_NAME = "\"time_received\"";

  public static final DataProcessor INSTANCE = new QuantityDataProcessor();

  private QuantityDataProcessor() {

  }
      
  @Override
  protected Set<Column> initColumns() {
    final Set<Column> columns = new HashSet<>();

    columns.add(new Column(QUANTITY_BRAND_ID_COLUMN_NAME));
    columns.add(new Column(QUANTITY_QUANTITY_COLUMN_NAME));
    columns.add(new Column(QUANTITY_TIME_RECIEVED_COLUMN_NAME));

    return columns;
  }

  @Override
  protected boolean validateDataRow(final String[] dataRow, final Set<Column> columns) {
    for (final Column column : columns) {
      if (column.getName().equalsIgnoreCase(QUANTITY_TIME_RECIEVED_COLUMN_NAME)
          && (dataRow[column.getIndex()] == null || dataRow[column.getIndex()].trim().isEmpty())) {
        return false;
      }
      if (column.getName().equalsIgnoreCase(QUANTITY_BRAND_ID_COLUMN_NAME)
          && (dataRow[column.getIndex()] == null
              || !Validator.validateNumber(dataRow[column.getIndex()]))) {
        return false;
      }
      if (column.getName().equalsIgnoreCase(QUANTITY_QUANTITY_COLUMN_NAME)
          && (dataRow[column.getIndex()] == null
              || !Validator.validateNumber(dataRow[column.getIndex()]))) {
        return false;

      }
    }
    return true;
  }

  @Override
  protected String formInsertStatement(final String[] dataRow, final Set<Column> columns) {
    return String.format(QUANTITY_INSERT_PATTERN,
        dataRow[findIndexByName(columns, QUANTITY_QUANTITY_COLUMN_NAME)],
        Timestamp.from(
            Instant.parse(dataRow[findIndexByName(columns, QUANTITY_TIME_RECIEVED_COLUMN_NAME)])),
        dataRow[findIndexByName(columns, QUANTITY_BRAND_ID_COLUMN_NAME)],
        dataRow[findIndexByName(columns, QUANTITY_BRAND_ID_COLUMN_NAME)]);
  }
}
