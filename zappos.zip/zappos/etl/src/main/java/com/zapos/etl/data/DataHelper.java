package com.zapos.etl.data;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/**
 * <h1>DataHelper</h1> Utility class provides ability to load data from tvs files and transform it
 * to sql statements.
 */
public class DataHelper {
  private static final String DATA_FILE_NAME = "data.sql";

  public static void fillDataFile(final String brandFileName, final String quantityFileName)
      throws IOException {
    if (brandFileName == null) {
      throw new IllegalArgumentException("brandFileName is null");
    }
    if (quantityFileName == null) {
      throw new IllegalArgumentException("quantityFileName is null");
    }

    final File brandsFile = new File(brandFileName);
    if (!brandsFile.exists() || !brandsFile.isFile()) {
      throw new IllegalArgumentException("Unable to process " + brandFileName);
    }

    final File quantityFile = new File(quantityFileName);
    if (!quantityFile.exists() || !quantityFile.isFile()) {
      throw new IllegalArgumentException("Unable to process " + quantityFileName);
    }

    final List<String> insertStatements =
        BrandDataProcessor.INSTANCE.prepareInsertStatements(brandsFile);
    insertStatements.addAll(QuantityDataProcessor.INSTANCE.prepareInsertStatements(quantityFile));

    writeDataFile(insertStatements);
  }

  private static void writeDataFile(List<String> insertStatements) throws IOException {

    try (final BufferedWriter writer = Files.newBufferedWriter(
        Paths.get(DataHelper.class.getClassLoader().getResource("").getFile(), DATA_FILE_NAME),
        Charset.forName("US-ASCII"))) {
      for (final String insertStatement : insertStatements) {
        writer.write(insertStatement, 0, insertStatement.length());
      }
    }

  }
}
