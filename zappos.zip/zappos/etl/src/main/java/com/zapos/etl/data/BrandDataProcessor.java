package com.zapos.etl.data;

import java.util.HashSet;
import java.util.Set;

/**
 * <h1>BrandDataProcessor</h1>
 * {@link DataProcessor} for {@code brand}.
 */
class BrandDataProcessor extends DataProcessor {
  private static final String BRAND_INSERT_PATTERN =
      "INSERT INTO `brand` (`id`, `name`) VALUES (%s, %s);";

  private static final String BRAND_ID_COLUMN_NAME = "\"brand_id\"";
  private static final String BRAND_NAME_COLUMN_NAME = "\"name\"";

  public static final DataProcessor INSTANCE = new BrandDataProcessor();

  private BrandDataProcessor() {

  }

  @Override
  protected Set<Column> initColumns() {
    final Set<Column> columns = new HashSet<>();

    columns.add(new Column(BRAND_ID_COLUMN_NAME));
    columns.add(new Column(BRAND_NAME_COLUMN_NAME));

    return columns;
  }

  @Override
  protected boolean validateDataRow(final String[] dataRow, final Set<Column> columns) {
    for (final Column column : columns) {
      if (column.getName().equalsIgnoreCase(BRAND_NAME_COLUMN_NAME)
          && (dataRow[column.getIndex()] == null || dataRow[column.getIndex()].trim().isEmpty())) {
        return false;
      }

      if (column.getName().equalsIgnoreCase(BRAND_ID_COLUMN_NAME)
          && (dataRow[column.getIndex()] == null
              || !Validator.validateNumber(dataRow[column.getIndex()]))) {
        return false;
      }

    }
    return true;
  }

  @Override
  protected String formInsertStatement(final String[] dataRow, final Set<Column> columns) {
    return String.format(BRAND_INSERT_PATTERN,
        dataRow[findIndexByName(columns, BRAND_ID_COLUMN_NAME)],
        dataRow[findIndexByName(columns, BRAND_NAME_COLUMN_NAME)]);
  }
}
